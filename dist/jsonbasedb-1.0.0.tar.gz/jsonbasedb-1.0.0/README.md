# jsonbasedb
A simple library for interacting with jsonbase.com
