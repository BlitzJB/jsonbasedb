 <img src="https://raw.githubusercontent.com/BlitzJB/jsonbasedb/main/docs/JsonBaseDB%20Banner%20Dark%20v2.png">
